"use client";

import dynamic from "next/dynamic";

// Three.js ne tourne que dans le navigateur : on charge la scène sans SSR.
const Scene = dynamic(() => import("./Portrait3DScene"), { ssr: false });

export default function Portrait3D({ className = "" }: { className?: string }) {
  return (
    <div
      className={`relative aspect-[1024/1066] w-full max-w-[520px] select-none ${className}`}
    >
      <Scene />
    </div>
  );
}
