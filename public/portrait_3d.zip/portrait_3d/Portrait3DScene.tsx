"use client";

import * as THREE from "three";
import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useLoader, useThree } from "@react-three/fiber";

/* ------------------------------------------------------------------ */
/*  RÉGLAGES (calibrés avec un rendu de test à ±15° / ±10°)            */
/* ------------------------------------------------------------------ */
const CONFIG = {
  basePath: "/layers/", // dossier public/layers/
  imgW: 1024,
  imgH: 1066,

  depthStrength: 0.18, // relief : en hauteur de plan (1 = hauteur du portrait). Baisse si ça s'étire.
  fov: 25,

  maxHeadYaw: 15, // degrés, gauche/droite
  maxHeadPitch: 8, // degrés, haut/bas
  maxBodyYaw: 2, // le corps bouge très peu
  maxIrisX: 9, // pixels (repère 1024x1066)
  maxIrisY: 4,

  irisK: 10, // vitesse de suivi des iris (plus grand = plus vif)
  headK: 5.5, // vitesse de la tête (plus lent : le regard précède la tête)
  idleMs: 2000, // retour au centre après ce délai sans mouvement

  faceCenter: { x: 490, y: 300 }, // centre du visage dans l'image (px)
  pivot: { x: 505, y: 500, depth: 0.4 }, // pivot de la tête : le cou
};

const D = 0.5 / Math.tan(THREE.MathUtils.degToRad(CONFIG.fov / 2)); // distance caméra
const ASPECT = CONFIG.imgW / CONFIG.imgH;

// px image -> unités monde (hauteur du portrait = 1)
const wx = (x: number) => (x - CONFIG.imgW / 2) / CONFIG.imgH;
const wy = (y: number) => -(y - CONFIG.imgH / 2) / CONFIG.imgH;

/* ------------------------------------------------------------------ */
/*  SHADERS                                                            */
/* ------------------------------------------------------------------ */
const vert = /* glsl */ `
uniform sampler2D uDepth;
uniform float uStrength;
uniform float uBias;
varying vec2 vUv;
void main() {
  vUv = uv;
  float d = texture2D(uDepth, uv).r;
  vec3 p = position;
  p.z += (d - 0.5) * uStrength + uBias;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
}
`;

// uOffset décale seulement l'échantillonnage de la texture (iris) ;
// le masque d'ouverture de l'œil est lu aux uv NON décalées : l'iris reste toujours coupé par la paupière.
const frag = /* glsl */ `
uniform sampler2D uMap;
uniform sampler2D uMask;
uniform vec2 uOffset;
uniform float uUseMask;
varying vec2 vUv;
void main() {
  vec4 c = texture2D(uMap, vUv - uOffset);
  float a = c.a;
  if (uUseMask > 0.5) a *= texture2D(uMask, vUv).a;
  if (a < 0.003) discard;
  gl_FragColor = vec4(c.rgb, a);
}
`;

/* ------------------------------------------------------------------ */
/*  Un calque = un plan texturé, déplacé en relief par la depth map    */
/* ------------------------------------------------------------------ */
type LayerProps = {
  geometry: THREE.BufferGeometry;
  map: THREE.Texture;
  depth: THREE.Texture;
  mask?: THREE.Texture;
  offsetRef?: React.MutableRefObject<THREE.Vector2>;
  strength?: number;
  bias?: number;
  renderOrder: number;
  depthWrite?: boolean;
};

function Layer({
  geometry,
  map,
  depth,
  mask,
  offsetRef,
  strength = CONFIG.depthStrength,
  bias = 0,
  renderOrder,
  depthWrite = true,
}: LayerProps) {
  const uniforms = useMemo(
    () => ({
      uMap: { value: map },
      uDepth: { value: depth },
      uMask: { value: mask ?? map },
      uStrength: { value: strength },
      uBias: { value: bias },
      uOffset: { value: new THREE.Vector2(0, 0) },
      uUseMask: { value: mask ? 1 : 0 },
    }),
    [map, depth, mask, strength, bias]
  );

  useFrame(() => {
    if (offsetRef) uniforms.uOffset.value.copy(offsetRef.current);
  });

  return (
    <mesh geometry={geometry} renderOrder={renderOrder} frustumCulled={false}>
      <shaderMaterial
        vertexShader={vert}
        fragmentShader={frag}
        uniforms={uniforms}
        transparent
        depthTest
        depthWrite={depthWrite}
      />
    </mesh>
  );
}

/* ------------------------------------------------------------------ */
/*  Scène                                                              */
/* ------------------------------------------------------------------ */
const FILES = [
  "10_background_plate.png",
  "20_body_neck_reconstructed.png",
  "31_eye_white_L.png",
  "31_eye_white_R.png",
  "32_iris_pupil_L.png",
  "32_iris_pupil_R.png",
  "33_eye_opening_mask_L.png",
  "33_eye_opening_mask_R.png",
  "40_head_frame.png",
  "depth.png",
];

function Scene() {
  const gl = useThree((s) => s.gl);
  const textures = useLoader(
    THREE.TextureLoader,
    FILES.map((f) => CONFIG.basePath + f)
  );
  const [bg, body, whiteL, whiteR, irisL, irisR, maskL, maskR, head, depth] =
    useMemo(() => {
      textures.forEach((t) => {
        t.colorSpace = THREE.NoColorSpace; // valeurs sRGB brutes : couleurs identiques à la photo
        t.minFilter = THREE.LinearFilter;
        t.magFilter = THREE.LinearFilter;
        t.generateMipmaps = false;
        t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
      });
      return textures;
    }, [textures]);

  // Même géométrie pour tous les calques en relief : les yeux restent collés au visage.
  const geometry = useMemo(
    () => new THREE.PlaneGeometry(ASPECT, 1, 256, 266),
    []
  );
  const flatGeometry = useMemo(() => new THREE.PlaneGeometry(ASPECT, 1, 1, 1), []);

  const headRig = useRef<THREE.Group>(null);
  const bodyRig = useRef<THREE.Group>(null);
  const bgRig = useRef<THREE.Group>(null);
  const irisOffset = useRef(new THREE.Vector2());

  const target = useRef({ x: 0, y: 0, last: 0 });
  const iris = useRef({ x: 0, y: 0 });
  const headState = useRef({ x: 0, y: 0 });

  const reduced = useRef(false);
  useEffect(() => {
    reduced.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }, []);

  // Suivi du pointeur (souris et tactile)
  useEffect(() => {
    const el = gl.domElement;
    const onMove = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      const fx = r.left + (r.width * CONFIG.faceCenter.x) / CONFIG.imgW;
      const fy = r.top + (r.height * CONFIG.faceCenter.y) / CONFIG.imgH;
      target.current.x = THREE.MathUtils.clamp((e.clientX - fx) / (window.innerWidth / 2), -1, 1);
      target.current.y = THREE.MathUtils.clamp((e.clientY - fy) / (window.innerHeight / 2), -1, 1);
      target.current.last = performance.now();
    };
    const onLeave = () => {
      target.current.x = 0;
      target.current.y = 0;
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    document.documentElement.addEventListener("pointerleave", onLeave);
    return () => {
      window.removeEventListener("pointermove", onMove);
      document.documentElement.removeEventListener("pointerleave", onLeave);
    };
  }, [gl]);

  const pivot = useMemo(
    () =>
      new THREE.Vector3(
        wx(CONFIG.pivot.x),
        wy(CONFIG.pivot.y),
        (CONFIG.pivot.depth - 0.5) * CONFIG.depthStrength
      ),
    []
  );
  const negPivot = useMemo(() => pivot.clone().multiplyScalar(-1), [pivot]);

  useFrame((_, delta) => {
    const amp = reduced.current ? 0.5 : 1;
    const idle = performance.now() - target.current.last > CONFIG.idleMs;
    const tx = idle ? 0 : target.current.x;
    const ty = idle ? 0 : target.current.y;

    const kI = 1 - Math.exp(-CONFIG.irisK * delta);
    const kH = 1 - Math.exp(-CONFIG.headK * delta);

    iris.current.x += (tx - iris.current.x) * kI;
    iris.current.y += (ty - iris.current.y) * kI;
    headState.current.x += (tx - headState.current.x) * kH;
    headState.current.y += (ty - headState.current.y) * kH;

    // décalage UV des iris (v est vers le haut, y écran vers le bas)
    irisOffset.current.set(
      (iris.current.x * CONFIG.maxIrisX * amp) / CONFIG.imgW,
      (-iris.current.y * CONFIG.maxIrisY * amp) / CONFIG.imgH
    );

    const hx = headState.current.x;
    const hy = headState.current.y;
    if (headRig.current) {
      headRig.current.rotation.y = THREE.MathUtils.degToRad(hx * CONFIG.maxHeadYaw * amp);
      headRig.current.rotation.x = THREE.MathUtils.degToRad(hy * CONFIG.maxHeadPitch * amp);
    }
    if (bodyRig.current) {
      bodyRig.current.rotation.y = THREE.MathUtils.degToRad(hx * CONFIG.maxBodyYaw * amp);
    }
    if (bgRig.current) {
      bgRig.current.position.x = -hx * 0.012 * amp;
      bgRig.current.position.y = hy * 0.008 * amp;
    }
  });

  const bgScale = (D + 0.14) / D; // le fond est plus loin : on le grossit pour qu'il remplisse le cadre

  return (
    <>
      {/* fond plat, légèrement en retrait */}
      <group ref={bgRig} position={[0, 0, -0.14]} scale={bgScale}>
        <Layer
          geometry={flatGeometry}
          map={bg}
          depth={depth}
          strength={0}
          renderOrder={0}
          depthWrite={false}
        />
      </group>

      {/* corps + cou : quasi fixe */}
      <group ref={bodyRig} position={pivot}>
        <group position={negPivot}>
          <Layer
            geometry={geometry}
            map={body}
            depth={depth}
            bias={-0.003}
            renderOrder={1}
          />
        </group>
      </group>

      {/* tête : blancs des yeux, iris, puis cadre de la tête par-dessus */}
      <group ref={headRig} position={pivot}>
        <group position={negPivot}>
          <Layer geometry={geometry} map={whiteL} depth={depth} bias={-0.004} renderOrder={2} depthWrite={false} />
          <Layer geometry={geometry} map={whiteR} depth={depth} bias={-0.004} renderOrder={2} depthWrite={false} />
          <Layer
            geometry={geometry}
            map={irisL}
            mask={maskL}
            offsetRef={irisOffset}
            depth={depth}
            bias={-0.0035}
            renderOrder={3}
            depthWrite={false}
          />
          <Layer
            geometry={geometry}
            map={irisR}
            mask={maskR}
            offsetRef={irisOffset}
            depth={depth}
            bias={-0.0035}
            renderOrder={3}
            depthWrite={false}
          />
          <Layer geometry={geometry} map={head} depth={depth} renderOrder={4} />
        </group>
      </group>
    </>
  );
}

export default function Portrait3DScene() {
  const [ready, setReady] = useState(false);
  return (
    <Canvas
      className={`transition-opacity duration-700 ${ready ? "opacity-100" : "opacity-0"}`}
      camera={{ fov: CONFIG.fov, position: [0, 0, D], near: 0.1, far: 10 }}
      dpr={[1, 2]}
      gl={{ alpha: true, antialias: true }}
      onCreated={() => setReady(true)}
    >
      <Suspense fallback={null}>
        <Scene />
      </Suspense>
    </Canvas>
  );
}
